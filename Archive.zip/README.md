# LtiCfg

Clean Architecture API на .NET 10 с интеграцией:
- MS SQL
- HashiCorp Vault (все runtime-настройки и connection string хранятся в Vault)
- Rebus (публикация и обработка событий)

## Структура
- `src/LtiCfg.Domain` - доменные контракты (события)
- `src/LtiCfg.Application` - use-case сервисы и абстракции
- `src/LtiCfg.Infrastructure` - Vault, SQL, Rebus реализации
- `src/LtiCfg.Api` - Web API

## Какие ключи ожидаются в Vault
Секрет: `secret/lticfg`
- `ConnectionStrings__Main`
- `Rebus__ConnectionString`
- `Rebus__InputQueue`
- `Rebus__Workers`
- `Api__ServiceName`

## Запуск в Docker
```bash
docker compose up --build
```

API будет доступен на `http://localhost:8080`.

## Тестовые endpoints
- `GET /api/diagnostics/ping` - тестовый метод API (с комментариями в коде)
- `POST /api/diagnostics/events` - publish события через Rebus
- `GET /api/diagnostics/db-check` - проверка подключения к MS SQL

Пример вызова publish:
```bash
curl -X POST http://localhost:8080/api/diagnostics/events \
  -H "Content-Type: application/json" \
  -d '{"message":"hello rebus"}'
```

## Примечание по SDK
Проект таргетирован на `net10.0` и ожидает .NET SDK 10 (`global.json`).
