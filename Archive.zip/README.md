# LtiCfg

Clean Architecture API на .NET 10 с интеграцией:
- PostgreSQL (две отдельные БД: основная и Rebus transport)
- Rebus (consumer + producer registration)
- gRPC + Protobuf для межсервисного взаимодействия

## Структура
- `src/LtiCfg.Domain` - доменные контракты (события)
- `src/LtiCfg.Application` - use-case сервисы и абстракции
- `src/LtiCfg.Contracts` - точка подключения gRPC/Protobuf контрактов
- `src/LtiCfg.Infrastructure` - Postgres, Rebus и env-конфигурация
- `src/LtiCfg.Api` - Web API

## Переменные окружения (обязательные)
- `MAIN_DB_CONNECTION_STRING` - строка подключения к основной Postgres БД
- `REBUS_DB_CONNECTION_STRING` - строка подключения к Postgres БД для Rebus transport

## Переменные окружения (опциональные)
- `SERVICE_NAME` (default: `LtiCfg.Api`)
- `REBUS_INPUT_QUEUE` (default: `lticfg.api`)
- `REBUS_WORKERS` (default: `1`)
- `REBUS_PRODUCER_ENABLED` (default: `false`)
- `REBUS_PRODUCER_INTERVAL_SECONDS` (default: `5`)

## Rebus: consumer и producer
- Consumer зарегистрирован через `IHandleMessages<TestIntegrationEvent>` (`TestIntegrationEventHandler`)
- Producer зарегистрирован как `BackgroundService` (`TestIntegrationEventProducerBackgroundService`) и включается флагом `REBUS_PRODUCER_ENABLED=true`

## Запуск в Docker
```bash
docker compose up --build
```

Контейнеры:
- `postgres-main` - основная БД (`lticfg_main`)
- `postgres-rebus` - БД транспортного слоя Rebus (`lticfg_rebus`)
- `api` - сервис

Доступ:
- REST API: `http://localhost:8080`
- Swagger UI: `http://localhost:8080/swagger`
- gRPC: `http://localhost:8081` (HTTP/2, h2c)

## Внешний JSON endpoint
- `PUT /integration/v1/companies/{companyId}` - создание/обновление компании по внешнему JSON-контракту

Пример вызова:
```bash
curl -X PUT http://localhost:8080/integration/v1/companies/3fa85f64-5717-4562-b3fc-2c963f66afa6 \
  -H "Content-Type: application/json" \
  -d '{
    "companyId":"3fa85f64-5717-4562-b3fc-2c963f66afa6",
    "companyName":"Ромашка",
    "companyInn":"6663003127",
    "kpp":"667101001",
    "status":"active",
    "avancorServer":"avancor-prod-01",
    "avancorDataBase":"avancor_main",
    "requestDateTime":"2025-02-15T14:00:00Z"
  }'
```

## Примечание по SDK
Проект таргетирован на `net10.0` и ожидает .NET SDK 10 (`global.json`).

## Контракты через git submodule
Рекомендуемый путь submodule:
- `submodules/company-protos`

Пример структуры репозитория контрактов:
```text
company-protos/
├── Protos/
│   ├── common/
│   │   └── types.proto
│   ├── user/
│   │   └── user.proto
│   └── integration/
│       └── company_integration.proto
├── build/
│   └── Company.Protos.targets
├── Company.Protos.csproj
└── Directory.Build.props
```

Подключение submodule:
```bash
git submodule add <your-protos-repo-url> submodules/company-protos
git submodule update --init --recursive
```

`LtiCfg.Contracts.csproj` автоматически импортирует `build/Company.Protos.targets`, если файл найден.
Если submodule не подключен, используется локальный fallback `src/LtiCfg.Contracts/Protos/interservice.proto`.
В этом репозитории уже создана локальная заготовка по пути `submodules/company-protos`, чтобы затем безболезненно заменить ее на private submodule с тем же путем.
