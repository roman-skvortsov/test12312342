using System.ComponentModel.DataAnnotations;

namespace LtiCfg.Api.Contracts.Integration;

/// <summary>
/// JSON-контракт входящего запроса на создание/обновление компании.
/// </summary>
public sealed class UpsertCompanyRequest
{
    /// <summary>
    /// ИД компании (routing key). Должен совпадать с параметром companyId в URL.
    /// </summary>
    [Required]
    public Guid CompanyId { get; init; }

    /// <summary>
    /// Наименование компании.
    /// </summary>
    [Required]
    [StringLength(150, MinimumLength = 1)]
    public string CompanyName { get; init; } = string.Empty;

    /// <summary>
    /// ИНН компании (10 или 12 цифр, в зависимости от типа компании).
    /// </summary>
    [Required]
    [RegularExpression("^\\d{10}(\\d{2})?$")]
    public string CompanyInn { get; init; } = string.Empty;

    /// <summary>
    /// КПП компании (ровно 9 цифр).
    /// </summary>
    [Required]
    [RegularExpression("^\\d{9}$")]
    public string Kpp { get; init; } = string.Empty;

    /// <summary>
    /// Статус участия компании в LTI.
    /// Допустимые значения: active, paused, closed.
    /// </summary>
    [Required]
    [RegularExpression("^(active|paused|closed)$")]
    public string Status { get; init; } = string.Empty;

    /// <summary>
    /// Сервер Avancor, в котором зарегистрирована компания.
    /// </summary>
    [Required]
    [StringLength(20, MinimumLength = 1)]
    public string AvancorServer { get; init; } = string.Empty;

    /// <summary>
    /// База данных Avancor, в которой зарегистрирована компания.
    /// </summary>
    [Required]
    [StringLength(20, MinimumLength = 1)]
    public string AvancorDataBase { get; init; } = string.Empty;

    /// <summary>
    /// Дата-время запроса от Avancor в UTC.
    /// Формат JSON: ISO-8601, пример: 2025-02-15T14:00:00Z.
    /// </summary>
    [Required]
    public DateTime RequestDateTime { get; init; }
}
