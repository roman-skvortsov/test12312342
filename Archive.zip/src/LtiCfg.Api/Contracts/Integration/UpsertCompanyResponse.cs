namespace LtiCfg.Api.Contracts.Integration;

/// <summary>
/// JSON-контракт ответа по операции создания/обновления компании.
/// </summary>
public sealed class UpsertCompanyResponse
{
    /// <summary>
    /// ИД компании, для которой обработан запрос.
    /// </summary>
    public Guid CompanyId { get; init; }

    /// <summary>
    /// Текущий статус участия компании в LTI.
    /// </summary>
    public string Status { get; init; } = string.Empty;

    /// <summary>
    /// UTC-время, когда сервис завершил обработку запроса.
    /// </summary>
    public DateTime ProcessedAtUtc { get; init; }

    /// <summary>
    /// Техническое сообщение о результате обработки.
    /// </summary>
    public string Message { get; init; } = string.Empty;
}
