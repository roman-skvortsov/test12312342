namespace LtiCfg.Api.Contracts;

public sealed class PublishEventRequest
{
    public string? Message { get; init; }
}
