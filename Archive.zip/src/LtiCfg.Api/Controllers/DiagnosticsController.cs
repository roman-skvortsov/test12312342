using LtiCfg.Api.Contracts;
using LtiCfg.Application.Abstractions;
using Microsoft.AspNetCore.Mvc;

namespace LtiCfg.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class DiagnosticsController : ControllerBase
{
    private readonly ITestScenarioService _testScenarioService;

    public DiagnosticsController(ITestScenarioService testScenarioService)
    {
        _testScenarioService = testScenarioService;
    }

    /// <summary>
    /// Тестовый метод API для быстрой проверки, что сервис запущен.
    /// </summary>
    /// <remarks>
    /// Этот метод не меняет состояние системы и может использоваться как smoke-check.
    /// </remarks>
    [HttpGet("ping")]
    public async Task<IActionResult> Ping(CancellationToken cancellationToken)
    {
        // Возвращаем простую диагностику: имя сервиса и текущее UTC-время.
        var response = await _testScenarioService.GetPingAsync(cancellationToken);
        return Ok(response);
    }

    /// <summary>
    /// Публикация тестового события через Rebus.
    /// </summary>
    [HttpPost("events")]
    public async Task<IActionResult> PublishEvent([FromBody] PublishEventRequest request, CancellationToken cancellationToken)
    {
        var eventId = await _testScenarioService.PublishTestEventAsync(request.Message ?? string.Empty, cancellationToken);
        return Accepted(new { EventId = eventId });
    }

    /// <summary>
    /// Проверка подключения к MS SQL с использованием строки из Vault.
    /// </summary>
    [HttpGet("db-check")]
    public async Task<IActionResult> CheckDb(CancellationToken cancellationToken)
    {
        var isConnected = await _testScenarioService.CheckDatabaseAsync(cancellationToken);
        return Ok(new { IsConnected = isConnected });
    }
}
