using LtiCfg.Api.Contracts.Integration;
using LtiCfg.Application.Abstractions.Integration;
using LtiCfg.Application.Models.Integration;
using Microsoft.AspNetCore.Mvc;

namespace LtiCfg.Api.Controllers.Integration;

[ApiController]
[Route("integration/v1/companies")]
public sealed class CompaniesController : ControllerBase
{
    private readonly ICompanyIntegrationService _companyIntegrationService;

    public CompaniesController(ICompanyIntegrationService companyIntegrationService)
    {
        _companyIntegrationService = companyIntegrationService;
    }

    /// <summary>
    /// Создает или обновляет компанию по внешнему интеграционному контракту.
    /// </summary>
    /// <param name="companyId">Идентификатор компании из URL (routing key).</param>
    /// <param name="request">Полный JSON-пакет данных компании.</param>
    /// <param name="cancellationToken">Токен отмены запроса.</param>
    /// <returns>Результат обработки интеграционного запроса.</returns>
    /// <response code="200">Запрос обработан успешно.</response>
    /// <response code="400">Ошибка валидации или несоответствие companyId в URL и body.</response>
    [HttpPut("{companyId:guid}")]
    [Produces("application/json")]
    [ProducesResponseType(typeof(UpsertCompanyResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<UpsertCompanyResponse>> UpsertCompany(
        [FromRoute] Guid companyId,
        [FromBody] UpsertCompanyRequest request,
        CancellationToken cancellationToken)
    {
        // Защита от рассинхронизации routing key и payload.
        if (request.CompanyId != companyId)
        {
            ModelState.AddModelError(nameof(request.CompanyId), "Body companyId must be equal to route companyId.");
            return ValidationProblem(ModelState);
        }

        // Маппинг transport DTO в application-модель.
        var applicationRequest = new CompanyUpsertRequest(
            CompanyId: request.CompanyId,
            CompanyName: request.CompanyName,
            CompanyInn: request.CompanyInn,
            Kpp: request.Kpp,
            Status: request.Status,
            AvancorServer: request.AvancorServer,
            AvancorDataBase: request.AvancorDataBase,
            RequestDateTimeUtc: DateTime.SpecifyKind(request.RequestDateTime, DateTimeKind.Utc));

        var result = await _companyIntegrationService.UpsertAsync(companyId, applicationRequest, cancellationToken);

        // Маппинг application-результата во внешний JSON-ответ.
        return Ok(new UpsertCompanyResponse
        {
            CompanyId = result.CompanyId,
            Status = result.Status,
            ProcessedAtUtc = result.ProcessedAtUtc,
            Message = result.Message
        });
    }
}
