using LtiCfg.Application.Abstractions.Integration;
using LtiCfg.Application.Models.Integration;
using LtiCfg.Contracts.V1;
using Grpc.Core;

namespace LtiCfg.Api.Grpc;

public sealed class InterserviceBridgeService : InterserviceBridge.InterserviceBridgeBase
{
    private readonly ICompanyIntegrationService _companyIntegrationService;

    public InterserviceBridgeService(ICompanyIntegrationService companyIntegrationService)
    {
        _companyIntegrationService = companyIntegrationService;
    }

    public override async Task<UpsertCompanyReply> UpsertCompany(UpsertCompanyRequest request, ServerCallContext context)
    {
        if (!Guid.TryParse(request.CompanyId, out var companyId))
        {
            throw new RpcException(new Status(StatusCode.InvalidArgument, "company_id must be a valid UUID."));
        }

        if (!DateTime.TryParse(request.RequestDateTimeUtc, out var requestDateTime))
        {
            throw new RpcException(new Status(StatusCode.InvalidArgument, "request_date_time_utc must be a valid ISO-8601 UTC datetime."));
        }

        var normalizedStatus = NormalizeStatus(request.Status.ToString());

        var appRequest = new CompanyUpsertRequest(
            CompanyId: companyId,
            CompanyName: request.CompanyName,
            CompanyInn: request.CompanyInn,
            Kpp: request.Kpp,
            Status: normalizedStatus,
            AvancorServer: request.AvancorServer,
            AvancorDataBase: request.AvancorDatabase,
            RequestDateTimeUtc: DateTime.SpecifyKind(requestDateTime, DateTimeKind.Utc));

        var result = await _companyIntegrationService.UpsertAsync(companyId, appRequest, context.CancellationToken);

        return new UpsertCompanyReply
        {
            CompanyId = result.CompanyId.ToString(),
            Status = result.Status,
            ProcessedAtUtc = result.ProcessedAtUtc.ToString("O"),
            Message = result.Message
        };
    }

    private static string NormalizeStatus(string source)
    {
        var value = source.Trim().ToLowerInvariant();

        return value switch
        {
            "active" or "company_status_active" => "active",
            "paused" or "company_status_paused" => "paused",
            "closed" or "company_status_closed" => "closed",
            _ => throw new RpcException(new Status(StatusCode.InvalidArgument, "status must be active, paused or closed."))
        };
    }
}
