using LtiCfg.Application.DependencyInjection;
using LtiCfg.Infrastructure.DependencyInjection;
using Rebus.ServiceProvider;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddApplication();
await builder.Services.AddInfrastructureAsync(builder.Configuration);

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();

app.UseRebus();

app.Run();
