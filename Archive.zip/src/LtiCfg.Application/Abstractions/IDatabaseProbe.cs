namespace LtiCfg.Application.Abstractions;

public interface IDatabaseProbe
{
    Task<bool> CanConnectAsync(CancellationToken cancellationToken = default);
}
