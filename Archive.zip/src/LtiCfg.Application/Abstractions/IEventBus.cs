using LtiCfg.Domain.Events;

namespace LtiCfg.Application.Abstractions;

public interface IEventBus
{
    Task PublishAsync(TestIntegrationEvent @event, CancellationToken cancellationToken = default);
}
