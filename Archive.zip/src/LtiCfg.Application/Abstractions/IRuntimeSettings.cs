namespace LtiCfg.Application.Abstractions;

public interface IRuntimeSettings
{
    string ServiceName { get; }
    string SqlConnectionString { get; }
    string RebusConnectionString { get; }
    string RebusInputQueue { get; }
    int RebusWorkers { get; }
}
