namespace LtiCfg.Application.Abstractions;

public interface IRuntimeSettings
{
    string ServiceName { get; }
    string MainDbConnectionString { get; }
    string RebusDbConnectionString { get; }
    string RebusInputQueue { get; }
    int RebusWorkers { get; }
    bool RebusProducerEnabled { get; }
    int RebusProducerIntervalSeconds { get; }
}
