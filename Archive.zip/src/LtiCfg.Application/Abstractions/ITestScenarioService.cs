using LtiCfg.Application.Models;

namespace LtiCfg.Application.Abstractions;

public interface ITestScenarioService
{
    Task<PingResponse> GetPingAsync(CancellationToken cancellationToken = default);
    Task<Guid> PublishTestEventAsync(string message, CancellationToken cancellationToken = default);
    Task<bool> CheckDatabaseAsync(CancellationToken cancellationToken = default);
}
