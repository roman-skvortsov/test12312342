using LtiCfg.Application.Models.Integration;

namespace LtiCfg.Application.Abstractions.Integration;

/// <summary>
/// Application-сервис для приема интеграционных данных по компании.
/// </summary>
public interface ICompanyIntegrationService
{
    /// <summary>
    /// Создает или обновляет сведения о компании по внешнему интеграционному контракту.
    /// </summary>
    Task<CompanyIntegrationResult> UpsertAsync(Guid companyId, CompanyUpsertRequest request, CancellationToken cancellationToken = default);
}
