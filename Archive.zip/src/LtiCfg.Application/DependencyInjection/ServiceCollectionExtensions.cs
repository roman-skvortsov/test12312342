using LtiCfg.Application.Abstractions.Integration;
using LtiCfg.Application.Services.Integration;
using Microsoft.Extensions.DependencyInjection;

namespace LtiCfg.Application.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<ICompanyIntegrationService, CompanyIntegrationService>();
        return services;
    }
}
