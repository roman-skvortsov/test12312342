namespace LtiCfg.Application.Models.Integration;

/// <summary>
/// Результат обработки интеграционного запроса по компании.
/// </summary>
public sealed record CompanyIntegrationResult(
    Guid CompanyId,
    string Status,
    DateTime ProcessedAtUtc,
    string Message);
