namespace LtiCfg.Application.Models.Integration;

/// <summary>
/// Внутренняя application-модель запроса на создание/обновление компании.
/// </summary>
public sealed record CompanyUpsertRequest(
    Guid CompanyId,
    string CompanyName,
    string CompanyInn,
    string Kpp,
    string Status,
    string AvancorServer,
    string AvancorDataBase,
    DateTime RequestDateTimeUtc);
