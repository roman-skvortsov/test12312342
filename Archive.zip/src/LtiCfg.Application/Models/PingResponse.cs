namespace LtiCfg.Application.Models;

public sealed record PingResponse(string ServiceName, DateTime UtcNow, string Message);
