using LtiCfg.Application.Abstractions.Integration;
using LtiCfg.Application.Models.Integration;

namespace LtiCfg.Application.Services.Integration;

/// <summary>
/// Базовая реализация сценария интеграционного upsert компании.
/// </summary>
public sealed class CompanyIntegrationService : ICompanyIntegrationService
{
    public Task<CompanyIntegrationResult> UpsertAsync(
        Guid companyId,
        CompanyUpsertRequest request,
        CancellationToken cancellationToken = default)
    {
        // Здесь должна быть доменная логика: валидация бизнес-правил, запись в БД,
        // публикация интеграционных событий и аудит операции.
        var result = new CompanyIntegrationResult(
            CompanyId: companyId,
            Status: request.Status,
            ProcessedAtUtc: DateTime.UtcNow,
            Message: "Company payload accepted for processing");

        return Task.FromResult(result);
    }
}
