using LtiCfg.Application.Abstractions;
using LtiCfg.Application.Models;
using LtiCfg.Domain.Events;

namespace LtiCfg.Application.Services;

public sealed class TestScenarioService : ITestScenarioService
{
    private readonly IRuntimeSettings _settings;
    private readonly IDatabaseProbe _databaseProbe;
    private readonly IEventBus _eventBus;

    public TestScenarioService(IRuntimeSettings settings, IDatabaseProbe databaseProbe, IEventBus eventBus)
    {
        _settings = settings;
        _databaseProbe = databaseProbe;
        _eventBus = eventBus;
    }

    public Task<PingResponse> GetPingAsync(CancellationToken cancellationToken = default)
    {
        var response = new PingResponse(
            ServiceName: _settings.ServiceName,
            UtcNow: DateTime.UtcNow,
            Message: "API is alive");

        return Task.FromResult(response);
    }

    public async Task<Guid> PublishTestEventAsync(string message, CancellationToken cancellationToken = default)
    {
        var @event = new TestIntegrationEvent(
            EventId: Guid.NewGuid(),
            Message: string.IsNullOrWhiteSpace(message) ? "Default test event" : message.Trim(),
            CreatedAtUtc: DateTime.UtcNow);

        await _eventBus.PublishAsync(@event, cancellationToken);

        return @event.EventId;
    }

    public Task<bool> CheckDatabaseAsync(CancellationToken cancellationToken = default)
    {
        return _databaseProbe.CanConnectAsync(cancellationToken);
    }
}
