# LtiCfg.Contracts

NuGet-пакет с общими Protobuf/gRPC контрактами для межсервисного взаимодействия.

Содержит:
- `InterserviceBridge` gRPC service contract
- `UpsertCompanyRequest` / `UpsertCompanyReply` модели
