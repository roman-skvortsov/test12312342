namespace LtiCfg.Domain.Events;

public sealed record TestIntegrationEvent(Guid EventId, string Message, DateTime CreatedAtUtc);
