using Microsoft.Extensions.Configuration;

namespace LtiCfg.Infrastructure.Configuration;

public static class EnvironmentRuntimeSettingsProvider
{
    public static RuntimeSettings Load(IConfiguration configuration)
    {
        // Строки подключений берем только из переменных окружения.
        var mainDb = GetRequired(configuration, "MAIN_DB_CONNECTION_STRING");
        var rebusDb = GetRequired(configuration, "REBUS_DB_CONNECTION_STRING");

        var workers = int.TryParse(configuration["REBUS_WORKERS"], out var parsedWorkers)
            ? Math.Max(1, parsedWorkers)
            : 1;

        var producerInterval = int.TryParse(configuration["REBUS_PRODUCER_INTERVAL_SECONDS"], out var parsedInterval)
            ? Math.Max(1, parsedInterval)
            : 5;

        var producerEnabled = bool.TryParse(configuration["REBUS_PRODUCER_ENABLED"], out var parsedEnabled) && parsedEnabled;

        return new RuntimeSettings
        {
            ServiceName = configuration["SERVICE_NAME"] ?? "LtiCfg.Api",
            MainDbConnectionString = mainDb,
            RebusDbConnectionString = rebusDb,
            RebusInputQueue = configuration["REBUS_INPUT_QUEUE"] ?? "lticfg.api",
            RebusWorkers = workers,
            RebusProducerEnabled = producerEnabled,
            RebusProducerIntervalSeconds = producerInterval
        };
    }

    private static string GetRequired(IConfiguration configuration, string key)
    {
        var value = configuration[key];
        if (string.IsNullOrWhiteSpace(value))
        {
            throw new InvalidOperationException($"Environment variable '{key}' is required.");
        }

        return value;
    }
}
