namespace LtiCfg.Infrastructure.Configuration;

public interface IVaultRuntimeSettingsProvider
{
    Task<RuntimeSettings> LoadAsync(CancellationToken cancellationToken = default);
}
