using LtiCfg.Application.Abstractions;

namespace LtiCfg.Infrastructure.Configuration;

public sealed class RuntimeSettings : IRuntimeSettings
{
    public string ServiceName { get; init; } = "LtiCfg.Api";
    public string MainDbConnectionString { get; init; } = string.Empty;
    public string RebusDbConnectionString { get; init; } = string.Empty;
    public string RebusInputQueue { get; init; } = "lticfg.api";
    public int RebusWorkers { get; init; } = 1;
    public bool RebusProducerEnabled { get; init; }
    public int RebusProducerIntervalSeconds { get; init; } = 5;
}
