using LtiCfg.Application.Abstractions;

namespace LtiCfg.Infrastructure.Configuration;

public sealed class RuntimeSettings : IRuntimeSettings
{
    public string ServiceName { get; init; } = "LtiCfg.Api";
    public string SqlConnectionString { get; init; } = string.Empty;
    public string RebusConnectionString { get; init; } = string.Empty;
    public string RebusInputQueue { get; init; } = "lticfg.api";
    public int RebusWorkers { get; init; } = 1;
}
