namespace LtiCfg.Infrastructure.Configuration;

public sealed class VaultBootstrapOptions
{
    public const string SectionName = "VaultBootstrap";

    public string Address { get; init; } = string.Empty;
    public string Token { get; init; } = string.Empty;
    public string MountPoint { get; init; } = "secret";
    public string SecretPath { get; init; } = "lticfg";
}
