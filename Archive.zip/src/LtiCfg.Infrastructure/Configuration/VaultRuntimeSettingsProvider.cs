using VaultSharp;
using VaultSharp.V1.AuthMethods.Token;
using VaultSharp.V1.Commons;

namespace LtiCfg.Infrastructure.Configuration;

public sealed class VaultRuntimeSettingsProvider : IVaultRuntimeSettingsProvider
{
    private readonly VaultBootstrapOptions _options;

    public VaultRuntimeSettingsProvider(VaultBootstrapOptions options)
    {
        _options = options;
    }

    public async Task<RuntimeSettings> LoadAsync(CancellationToken cancellationToken = default)
    {
        ValidateOptions(_options);

        var authMethod = new TokenAuthMethodInfo(_options.Token);
        var vaultClientSettings = new VaultClientSettings(_options.Address, authMethod);
        var vaultClient = new VaultClient(vaultClientSettings);

        Secret<SecretData> secret = await vaultClient.V1.Secrets.KeyValue.V2.ReadSecretAsync(
            path: _options.SecretPath,
            mountPoint: _options.MountPoint,
            cancellationToken: cancellationToken);

        var data = secret.Data.Data;

        var sql = GetRequired(data, "ConnectionStrings__Main");
        var rebusConnection = GetRequired(data, "Rebus__ConnectionString");

        var rebusWorkersValue = data.TryGetValue("Rebus__Workers", out var workersRaw)
            ? workersRaw?.ToString()
            : null;

        var rebusWorkers = int.TryParse(rebusWorkersValue, out var parsedWorkers)
            ? Math.Max(1, parsedWorkers)
            : 1;

        return new RuntimeSettings
        {
            ServiceName = data.TryGetValue("Api__ServiceName", out var serviceName)
                ? serviceName?.ToString() ?? "LtiCfg.Api"
                : "LtiCfg.Api",
            SqlConnectionString = sql,
            RebusConnectionString = rebusConnection,
            RebusInputQueue = data.TryGetValue("Rebus__InputQueue", out var queue)
                ? queue?.ToString() ?? "lticfg.api"
                : "lticfg.api",
            RebusWorkers = rebusWorkers
        };
    }

    private static void ValidateOptions(VaultBootstrapOptions options)
    {
        if (string.IsNullOrWhiteSpace(options.Address))
        {
            throw new InvalidOperationException("VaultBootstrap:Address is required.");
        }

        if (string.IsNullOrWhiteSpace(options.Token))
        {
            throw new InvalidOperationException("VaultBootstrap:Token is required.");
        }

        if (string.IsNullOrWhiteSpace(options.SecretPath))
        {
            throw new InvalidOperationException("VaultBootstrap:SecretPath is required.");
        }

        if (string.IsNullOrWhiteSpace(options.MountPoint))
        {
            throw new InvalidOperationException("VaultBootstrap:MountPoint is required.");
        }
    }

    private static string GetRequired(IDictionary<string, object> data, string key)
    {
        if (!data.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value?.ToString()))
        {
            throw new InvalidOperationException($"Vault secret '{key}' is required.");
        }

        return value!.ToString()!;
    }
}
