using LtiCfg.Application.Abstractions;
using Npgsql;

namespace LtiCfg.Infrastructure.Data;

public sealed class PostgresDatabaseProbe : IDatabaseProbe
{
    private readonly IRuntimeSettings _settings;

    public PostgresDatabaseProbe(IRuntimeSettings settings)
    {
        _settings = settings;
    }

    public async Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = new NpgsqlConnection(_settings.MainDbConnectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT 1";

        var result = await command.ExecuteScalarAsync(cancellationToken);

        return result is int value && value == 1;
    }
}
