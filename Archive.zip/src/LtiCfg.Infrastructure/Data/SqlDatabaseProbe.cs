using LtiCfg.Application.Abstractions;
using Microsoft.Data.SqlClient;

namespace LtiCfg.Infrastructure.Data;

public sealed class SqlDatabaseProbe : IDatabaseProbe
{
    private readonly IRuntimeSettings _settings;

    public SqlDatabaseProbe(IRuntimeSettings settings)
    {
        _settings = settings;
    }

    public async Task<bool> CanConnectAsync(CancellationToken cancellationToken = default)
    {
        await using var connection = new SqlConnection(_settings.SqlConnectionString);
        await connection.OpenAsync(cancellationToken);

        await using var command = connection.CreateCommand();
        command.CommandText = "SELECT 1";

        var result = await command.ExecuteScalarAsync(cancellationToken);

        return result is int value && value == 1;
    }
}
