using LtiCfg.Application.Abstractions;
using LtiCfg.Infrastructure.Configuration;
using LtiCfg.Infrastructure.Data;
using LtiCfg.Infrastructure.Messaging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Rebus.SqlServer;
using Rebus.Config;
using Rebus.Retry.Simple;
using Rebus.ServiceProvider;

namespace LtiCfg.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static async Task<IServiceCollection> AddInfrastructureAsync(
        this IServiceCollection services,
        IConfiguration configuration,
        CancellationToken cancellationToken = default)
    {
        var bootstrap = configuration
            .GetSection(VaultBootstrapOptions.SectionName);

        var bootstrapOptions = new VaultBootstrapOptions
        {
            Address = bootstrap["Address"] ?? string.Empty,
            Token = bootstrap["Token"] ?? string.Empty,
            MountPoint = bootstrap["MountPoint"] ?? "secret",
            SecretPath = bootstrap["SecretPath"] ?? "lticfg"
        };

        IVaultRuntimeSettingsProvider provider = new VaultRuntimeSettingsProvider(bootstrapOptions);
        var runtimeSettings = await provider.LoadAsync(cancellationToken);

        services.AddSingleton<IRuntimeSettings>(runtimeSettings);

        services.AddScoped<IDatabaseProbe, SqlDatabaseProbe>();
        services.AddScoped<IEventBus, RebusEventBus>();

        services.AddRebus((configurer, _) => configurer
            .Transport(transport => transport.UseSqlServer(runtimeSettings.RebusConnectionString, runtimeSettings.RebusInputQueue))
            .Options(options =>
            {
                options.SimpleRetryStrategy(maxDeliveryAttempts: 5);
                options.SetNumberOfWorkers(runtimeSettings.RebusWorkers);
                options.SetMaxParallelism(runtimeSettings.RebusWorkers);
            }));

        services.AutoRegisterHandlersFromAssemblyOf<TestIntegrationEventHandler>();
        services.AddHostedService<RebusSubscriptionStartupService>();

        return services;
    }
}
