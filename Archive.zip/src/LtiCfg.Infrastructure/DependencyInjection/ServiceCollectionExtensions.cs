using LtiCfg.Application.Abstractions;
using LtiCfg.Infrastructure.Configuration;
using LtiCfg.Infrastructure.Data;
using LtiCfg.Infrastructure.Messaging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Rebus.Config;
using Rebus.PostgreSql;
using Rebus.Retry.Simple;
using Rebus.ServiceProvider;

namespace LtiCfg.Infrastructure.DependencyInjection;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddInfrastructure(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var runtimeSettings = EnvironmentRuntimeSettingsProvider.Load(configuration);

        services.AddSingleton<IRuntimeSettings>(runtimeSettings);

        services.AddScoped<IDatabaseProbe, PostgresDatabaseProbe>();
        services.AddScoped<IEventBus, RebusEventBus>();

        services.AddRebus((configurer, _) => configurer
            .Transport(transport => transport.UsePostgreSql(runtimeSettings.RebusDbConnectionString, runtimeSettings.RebusInputQueue))
            .Options(options =>
            {
                options.SimpleRetryStrategy(maxDeliveryAttempts: 5);
                options.SetNumberOfWorkers(runtimeSettings.RebusWorkers);
                options.SetMaxParallelism(runtimeSettings.RebusWorkers);
            }));

        services.AutoRegisterHandlersFromAssemblyOf<TestIntegrationEventHandler>();
        services.AddHostedService<RebusSubscriptionStartupService>();
        if (runtimeSettings.RebusProducerEnabled)
        {
            services.AddHostedService<TestIntegrationEventProducerBackgroundService>();
        }

        return services;
    }
}
