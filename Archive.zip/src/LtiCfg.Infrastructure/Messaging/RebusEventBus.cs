using LtiCfg.Application.Abstractions;
using LtiCfg.Domain.Events;
using Rebus.Bus;

namespace LtiCfg.Infrastructure.Messaging;

public sealed class RebusEventBus : IEventBus
{
    private readonly IBus _bus;

    public RebusEventBus(IBus bus)
    {
        _bus = bus;
    }

    public Task PublishAsync(TestIntegrationEvent @event, CancellationToken cancellationToken = default)
    {
        return _bus.Publish(@event);
    }
}
