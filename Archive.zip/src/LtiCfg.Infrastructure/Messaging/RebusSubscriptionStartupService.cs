using LtiCfg.Domain.Events;
using Microsoft.Extensions.Hosting;
using Rebus.Bus;

namespace LtiCfg.Infrastructure.Messaging;

public sealed class RebusSubscriptionStartupService : IHostedService
{
    private readonly IBus _bus;

    public RebusSubscriptionStartupService(IBus bus)
    {
        _bus = bus;
    }

    public Task StartAsync(CancellationToken cancellationToken)
    {
        return _bus.Subscribe<TestIntegrationEvent>();
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }
}
