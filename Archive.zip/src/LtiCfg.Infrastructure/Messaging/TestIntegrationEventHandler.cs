using LtiCfg.Domain.Events;
using Microsoft.Extensions.Logging;
using Rebus.Handlers;

namespace LtiCfg.Infrastructure.Messaging;

public sealed class TestIntegrationEventHandler : IHandleMessages<TestIntegrationEvent>
{
    private readonly ILogger<TestIntegrationEventHandler> _logger;

    public TestIntegrationEventHandler(ILogger<TestIntegrationEventHandler> logger)
    {
        _logger = logger;
    }

    public Task Handle(TestIntegrationEvent message)
    {
        _logger.LogInformation(
            "Rebus event received: {EventId}; CreatedAtUtc={CreatedAtUtc}; Message={Message}",
            message.EventId,
            message.CreatedAtUtc,
            message.Message);

        return Task.CompletedTask;
    }
}
