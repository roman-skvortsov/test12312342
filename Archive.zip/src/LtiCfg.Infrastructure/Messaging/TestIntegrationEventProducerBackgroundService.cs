using LtiCfg.Application.Abstractions;
using LtiCfg.Domain.Events;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Rebus.Bus;

namespace LtiCfg.Infrastructure.Messaging;

/// <summary>
/// Пример producer-а: периодически публикует тестовое событие в Rebus.
/// </summary>
public sealed class TestIntegrationEventProducerBackgroundService : BackgroundService
{
    private readonly ILogger<TestIntegrationEventProducerBackgroundService> _logger;
    private readonly IBus _bus;
    private readonly IRuntimeSettings _settings;

    public TestIntegrationEventProducerBackgroundService(
        ILogger<TestIntegrationEventProducerBackgroundService> logger,
        IBus bus,
        IRuntimeSettings settings)
    {
        _logger = logger;
        _bus = bus;
        _settings = settings;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            var @event = new TestIntegrationEvent(
                EventId: Guid.NewGuid(),
                Message: $"Producer tick from {_settings.ServiceName}",
                CreatedAtUtc: DateTime.UtcNow);

            _logger.LogInformation("Publish test event: {EventId}", @event.EventId);
            await _bus.Publish(@event);

            await Task.Delay(TimeSpan.FromSeconds(_settings.RebusProducerIntervalSeconds), stoppingToken);
        }
    }
}
