# company-protos

Локальная заготовка репозитория контрактов.

Целевой путь в основном проекте: `submodules/company-protos`.
Позже эту папку можно заменить на private git submodule без изменения путей в `LtiCfg.Contracts.csproj`.

Содержимое:
- `Protos/` - protobuf-контракты
- `build/Company.Protos.targets` - импорт proto в потребляющие проекты
- `Company.Protos.csproj` - отдельный проект контрактов
